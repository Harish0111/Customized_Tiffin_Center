package com.expleo.TiffinService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiffinServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiffinServiceApplication.class, args);
	}

}
