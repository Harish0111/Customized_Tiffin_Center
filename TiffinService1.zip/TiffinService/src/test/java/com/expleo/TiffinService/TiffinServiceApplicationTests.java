package com.expleo.TiffinService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiffinServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
